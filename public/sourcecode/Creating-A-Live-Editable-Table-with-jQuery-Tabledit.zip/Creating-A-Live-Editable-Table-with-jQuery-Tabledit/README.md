# jQuery-Tabledit v1.2.2
Inline editor for HTML tables compatible with Bootstrap.


## Examples
http://markcell.github.io/jQuery-Tabledit/#examples


## Documentation
http://markcell.github.io/jQuery-Tabledit/#documentation


## Changelog
See CHANGELOG.md file.


## License
Code released under the MIT license.
