<?php
/*
  This page returns the image requested from the database.  Since there are several different ways the image can be queried for, the first image will be returned.
  Call as: http://www.yoursite.com/imgView.php?id=1
  Author: Joe McCormack
  Site: www.virtualsecrets.com
*/
global $imgMime;
global $imgSize;
global $imgData;
$error_status = 0;
$requestedID = 0;

/*
  DATABASE TABLE STRUCTURE (for this example):
	CREATE TABLE imgUploadTbl (
	imgID INT NOT NULL AUTO_INCREMENT
	, imgCreatedOn DATETIME NOT NULL
	, imgUpdatedOn TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	, imgDimension VARCHAR(100) NOT NULL
	, imgMime VARCHAR(255) NOT NULL
	, imgSize INT NOT NULL
	, imgData LONGBLOB NOT NULL
	, PRIMARY KEY(imgID))
*/
function imgRetrieve($id) {
global $imgMime;
global $imgSize;
global $imgData;
$status = "success";
$mySQLLogin = "mySQL user name with permissions to select and insert data";
$mySQLPassword = "mySQL user password with permissions to select and insert data";
$mySQLDatabaseName = "testingDB";
$mySQLDatabaseTableName = "imgUploadTbl";

// Setup connection
$connDB = new PDO("mysql:host=localhost;dbname=$mySQLDatabaseName", $mySQLLogin, $mySQLPassword);
$connDB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
try {
     // Query
     $statement = $connDB->prepare("SELECT imgMime, imgSize, imgData FROM '$mySQLDatabaseTableName' WHERE imgID = :imgID");
     // Assign and execute query
     $statement->bindParam(':imgID', $id, PDO::PARAM_INT);
     $statement->setFetchMode(PDO::FETCH_ASSOC);
     $statement->execute();
     // Get data
     while($row = $statement->fetch()) {
					$imgMime = $row['imgMime'];
					$imgSize = $row['imgSize'];
					$imgData = $row['imgData'];
				       }
    }
catch(PDOException $e) { $status = $e->getMessage(); }

//Close the connection
$connDB = null;
return $status;
}


/*
  PROCESS THE REQUEST FOR THE IMAGE
*/
try { $requestedID = (int)$_GET[id]; }
catch (Exception $e) { $error_status = 1; }
if ($error_status == 0) {
			 $status = imgRetrieve($requestedID);
			 if ($status == "success") {
						    if ((int)$imgSize > 0) {
									    header('Content-type: ' . $imgMime);
									    header('Content-length: ' . $imgSize);
									    echo $imgData;
									   }
						    else { header('HTTP/1.0 404 Not Found'); }
						   }
			 else { header('HTTP/1.0 500 Internal Server Error'); }
			}
else { header('HTTP/1.0 400 Bad Request'); }

exit;
?>