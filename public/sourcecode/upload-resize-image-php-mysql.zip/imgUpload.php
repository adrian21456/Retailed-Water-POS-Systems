<?php
/*
  Simple Image Upload Form
  Author: Joe McCormack
  Site: www.virtualsecrets.com
*/
?>

<html><head>
<title>Upload An Image</title>
</head><body>
You can add your own picture (JPG, PNG) by selecting the image below.<br /><br />
<form method="post" action="imgUploadHandle.php" enctype="multipart/form-data">
	<input type="file" name="image" />
	<input type="submit" id="userSbtBtn" value="Upload Image" />
</form>
</body>
</html>
